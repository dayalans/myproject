package az.ingress.students;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentsDemoApplication.class, args);
	}

}
