Read medium post https://medium.com/@iyusubov444/spring-rest-api-exception-handling-a312eafe85e7 for details
