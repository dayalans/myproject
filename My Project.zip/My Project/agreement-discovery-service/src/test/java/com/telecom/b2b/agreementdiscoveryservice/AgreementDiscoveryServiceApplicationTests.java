package com.telecom.b2b.agreementdiscoveryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgreementDiscoveryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
