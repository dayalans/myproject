package com.telecom.b2b.account.service.api.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountServiceApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
