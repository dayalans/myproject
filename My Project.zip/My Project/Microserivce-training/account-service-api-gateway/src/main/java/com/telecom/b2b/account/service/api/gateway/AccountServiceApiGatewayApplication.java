package com.telecom.b2b.account.service.api.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountServiceApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountServiceApiGatewayApplication.class, args);
	}

}
