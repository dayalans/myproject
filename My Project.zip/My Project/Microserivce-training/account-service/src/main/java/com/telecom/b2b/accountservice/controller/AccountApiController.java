package com.telecom.b2b.accountservice.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/account")
public class AccountApiController {
    @GetMapping("/status/check")
    public String status() {
        return "Working";
    }
}
