package lectures;


import static org.assertj.core.api.Assertions.assertThat;

import beans.Car;
import com.google.common.collect.ImmutableList;
import java.math.BigDecimal;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.stream.Collectors;
import mockdata.MockData;
import org.junit.Test;

public class Lecture7 {

  @Test
  public void count() throws Exception {
	  long count=MockData.getPeople()
			  .stream()
			  .filter(p->p.getGender().equalsIgnoreCase("Female")).count();
System.out.println(count);
  }

  @Test
  public void min() throws Exception {
	  
	  List<Car> carsData = MockData.getCars();
	  double minprice=carsData.stream().filter(cars->cars.getColor().equalsIgnoreCase("Yellow"))
	  .mapToDouble(Car::getPrice).min().getAsDouble();
	  System.out.println("minprice "+minprice);

  }

  @Test
  public void max() throws Exception {
	  List<Car> carsData = MockData.getCars();
	  double minprice=carsData.stream().filter(cars->cars.getColor().equalsIgnoreCase("Yellow"))
	  .mapToDouble(Car::getPrice).max().getAsDouble();
	  System.out.println("minprice "+minprice);
  }


  @Test
  public void average() throws Exception {
	  List<Car> carsData = MockData.getCars();
	  double avgprice=carsData.stream().mapToDouble(Car::getPrice).average().orElse(0);
	  System.out.println("avgprice "+avgprice);
  }

  @Test
  public void sum() throws Exception {
    List<Car> cars = MockData.getCars();

    double avgsum=cars.stream().mapToDouble(Car::getPrice).sum();
    BigDecimal big=BigDecimal.valueOf(avgsum);
    System.out.println("avgsum "+avgsum);
    System.out.println("big "+big);
  }

  @Test
  public void statistics() throws Exception {
    List<Car> cars = MockData.getCars();
    
    DoubleSummaryStatistics stats=cars.stream().mapToDouble(Car::getPrice).summaryStatistics();
    System.out.println("stats "+stats);
    System.out.println("stats "+stats.getAverage());
    System.out.println("stats "+stats.getCount());
    System.out.println("stats "+stats.getMax());
    System.out.println("stats "+stats.getMin());    
    System.out.println("stats "+stats.getSum());
    

  }

}