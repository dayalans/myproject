package lectures;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Test;

import beans.Person;
import mockdata.MockData;


public class Lecture1 {

  @Test
  public void imperativeApproach() throws IOException {
    List<Person> people = MockData.getPeople();
    // 1. Find people aged less or equal 18
    // 2. Then change implementation to find first 10 people
    List<Person> people18= new ArrayList<Person>();
    for (Person person : people) {
		if(person.getAge()<=18) {
			people18.add(person);
		}
	}
    List<Person> people10= new ArrayList<Person>();
    
  }

  @Test
  public void declarativeApproachUsingStreams() throws Exception {
 MockData.getPeople().stream()
 .filter(p->p.getAge()<=18)
 .limit(10)
 .collect(Collectors.toList())
 .forEach(System.out::println);
    

  }
}
