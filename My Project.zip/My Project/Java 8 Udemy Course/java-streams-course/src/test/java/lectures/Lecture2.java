package lectures;

import beans.Person;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import mockdata.MockData;
import org.junit.Test;

public class Lecture2 {

  @Test
  public void range() throws Exception {

  }

  

  @Test
  public void intStreamIterate() throws Exception {
     IntStream.iterate(1, operand->operand+1)
     .filter(number->number%number==0)
     .limit(20)
     .forEach(System.out::println);
     
  }
  

  @Test
  public void intStreamIteratePrime() throws Exception {
     Stream.iterate(0, n->n+1)
     .limit(100)
     .filter(Lecture2::isPrime)
     .peek(x -> System.out.format("%s\t", x)).forEach(System.out::println);
     
  }
  
  public static boolean isPrime(int number) {

      if (number <= 1) return false; // 1 is not prime and also not composite

      return !IntStream.rangeClosed(2, number / 2).anyMatch(i -> number % i == 0);
  }
}
