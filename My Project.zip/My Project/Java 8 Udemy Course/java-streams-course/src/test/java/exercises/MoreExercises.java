package exercises;

public class MoreExercises {
  // TODO: Coming soon
}
