package com.telecom.b2b.ucinstance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UcinstanceMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UcinstanceMicroserviceApplication.class, args);
	}

}
