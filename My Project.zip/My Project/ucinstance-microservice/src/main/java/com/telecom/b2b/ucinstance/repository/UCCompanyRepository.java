package com.telecom.b2b.ucinstance.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telecom.b2b.ucinstance.entity.UCCompany;

public interface UCCompanyRepository extends JpaRepository<UCCompany,String> {

}

