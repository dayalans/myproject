package com.telecom.b2b.ucinstancemicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UcinstanceMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
