package com.tele.orderengine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgreementOrderengineApplicationTests {

	@Test
	void contextLoads() {
	}

}
