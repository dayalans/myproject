package com.tele.orderengine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgreementOrderengineApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgreementOrderengineApplication.class, args);
	}

}
