package com.exception.management.exceptionhandling.service;

import java.util.List;

import com.exception.management.exceptionhandling.Entity.City;


public interface ICityService {
	City findById(Long id);
    City save(City city);
    List<City> findAll();
    List<City> getUsersByPagination(int pageNo, int pageSize);
    Iterable<City> getUsersByPaginationAndSort(int pageNo, int pageSize,String fieldName,String order);
}
