package com.exception.management.exceptionhandling.serviceimpl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.exception.management.exceptionhandling.Entity.City;
import com.exception.management.exceptionhandling.exception.CityNotFoundException;
import com.exception.management.exceptionhandling.exception.NoDataFoundException;
import com.exception.management.exceptionhandling.repository.CityPagingRepository;
import com.exception.management.exceptionhandling.repository.CityRepository;
import com.exception.management.exceptionhandling.service.ICityService;

@Service
public class CityServiceImpl implements ICityService {
	  @Autowired
   CityRepository cityRepository;
    @Autowired
    CityPagingRepository cityPagingRepository;

    
    @Override
    public City findById(Long id) {

        return cityRepository.findById(id)
                .orElseThrow(() -> new CityNotFoundException(id));
    }

    @Override
    public City save(City city) {

        return cityRepository.save(city);
    }

    @Override
    public List<City> findAll() {

        var cities = (List<City>) cityRepository.findAll();

        if (cities.isEmpty()) {

            throw new NoDataFoundException();
        }

        return cities;
    }

	@Override
	public List<City> getUsersByPagination(int pageNo, int pageSize) {
		PageRequest pageRequest = PageRequest.of(pageNo, pageSize);
        //pass it to repos
        Page<City> pagingUser = cityPagingRepository.findAll(pageRequest);
        //pagingUser.hasContent(); -- to check pages are there or not
        return pagingUser.getContent();
	}

	@Override
	public Iterable<City> getUsersByPaginationAndSort(int pageNo, int pageSize, String fieldName, String order) {
		
		PageRequest pageRequest;
		if(order.equals("asc"))
		pageRequest = PageRequest.of(pageNo, pageSize, Sort.by(fieldName).ascending());
		else
		{
			pageRequest = PageRequest.of(pageNo, pageSize, Sort.by(fieldName).descending());;
		}
		Page<City> pagingUser = cityPagingRepository.findAll(pageRequest);
		/*
		 * pagingUser.hasContent(); -- to check pages are there or not Sort nameSort =
		 * Sort.by("name"); Sort emailSort = Sort.by("email");
		 * 
		 * Sort multiSort = emailSort.and(nameSort);
		 * 
		 * List<EmployeeEntity> result = repository.findAll(multiSort);
		 */
        return pagingUser.getContent();
		
	}
}
