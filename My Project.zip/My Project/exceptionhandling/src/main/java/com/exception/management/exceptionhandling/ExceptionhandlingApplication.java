package com.exception.management.exceptionhandling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExceptionhandlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExceptionhandlingApplication.class, args);
	}

}
