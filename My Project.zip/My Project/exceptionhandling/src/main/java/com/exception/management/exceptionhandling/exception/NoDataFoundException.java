package com.exception.management.exceptionhandling.exception;



public class NoDataFoundException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1547374461753316391L;

	public NoDataFoundException() {

        super("No data found");
    }
}
