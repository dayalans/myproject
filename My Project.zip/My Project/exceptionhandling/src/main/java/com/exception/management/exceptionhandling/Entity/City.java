package com.exception.management.exceptionhandling.Entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Range;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "cities")
public class City {

	 @Id
	    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CITY_SEQ")
	    @SequenceGenerator(sequenceName = "city_seq", allocationSize = 1, name = "CITY_SEQ")
    private Long id;

    @NotEmpty
    private String name;

    @NotNull
    @Past(message = "ErrorMessages.INVALID_CAMPAIGN_START_DATE")
    private LocalDate birthday;
    
    @NotNull
    @Future(message = "ErrorMessages.INVALID_CAMPAIGN_START_DATE")
    private LocalDate endDate;
    
 
    @javax.validation.constraints.Email
    private String email;
   
    @Pattern(regexp="[\\d]{6}",message = "Pincode must be 5 digits")
    private String pincode;    
    

    @Range(min=10, max=100_000_000)
    private int population;
}