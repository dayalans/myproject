package com.exception.management.exceptionhandling.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.exception.management.exceptionhandling.Entity.City;

public interface  CityPagingRepository extends PagingAndSortingRepository<City, Integer>{

}
