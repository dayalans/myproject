package com.exception.management.exceptionhandling.repository;

import org.springframework.data.repository.CrudRepository;

import com.exception.management.exceptionhandling.Entity.City;

public interface CityRepository extends CrudRepository<City, Long>{

}
