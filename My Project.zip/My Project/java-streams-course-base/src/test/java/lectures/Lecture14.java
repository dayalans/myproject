package lectures;

public class Lecture14 {
  /*
    1. Concrete to abstraction - invoke stream
    2. Multiple operations map, filter, flatmap, average, sum, min, max n...
      - Intermediate operations are lazy.
    3. Terminal operators collect streams back to concrete type. .collect, .get
  */

  // parallel streams ?
}
