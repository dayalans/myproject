package com.agreement.consumer.agreementconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgreementConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
