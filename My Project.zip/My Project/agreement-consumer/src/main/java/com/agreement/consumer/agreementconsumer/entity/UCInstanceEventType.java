package com.agreement.consumer.agreementconsumer.entity;

public enum UCInstanceEventType {
    CREATE,
    UPDATE,
    DELETE
}