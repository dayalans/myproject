package com.agreement.consumer.agreementconsumer.entity;


public enum AgreementEventType {
    CREATE,
    UPDATE,
    DELETE
}


