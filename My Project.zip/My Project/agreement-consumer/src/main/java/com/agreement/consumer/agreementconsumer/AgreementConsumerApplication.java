package com.agreement.consumer.agreementconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgreementConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgreementConsumerApplication.class, args);
	}

}
