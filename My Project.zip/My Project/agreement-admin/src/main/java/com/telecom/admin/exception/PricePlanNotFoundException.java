package com.telecom.admin.exception;

public class PricePlanNotFoundException {

}
