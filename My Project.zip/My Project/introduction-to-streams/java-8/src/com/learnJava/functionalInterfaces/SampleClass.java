package com.learnJava.functionalInterfaces;

public class SampleClass {
    public static void main(String[] args) {
        System.out.println("Hello WOrld");
    }
}
