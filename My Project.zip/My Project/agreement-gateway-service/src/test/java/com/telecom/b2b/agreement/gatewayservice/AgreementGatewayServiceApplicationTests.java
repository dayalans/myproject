package com.telecom.b2b.agreement.gatewayservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgreementGatewayServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
