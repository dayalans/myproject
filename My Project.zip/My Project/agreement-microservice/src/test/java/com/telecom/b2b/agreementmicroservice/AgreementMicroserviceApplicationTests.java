package com.telecom.b2b.agreementmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgreementMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
