package com.telecom.b2b.agreementmicroservice.service;

import com.telecom.b2b.agreementmicroservice.entity.PricePlans;

public interface PricePlanService {
    public PricePlans savePricePlan(PricePlans pricePlans);
}
