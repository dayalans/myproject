package com.telecom.b2b.agreementmicroservice.entity;

public enum AgreementEventType {
    CREATE,
    UPDATE,
    DELETE
}
