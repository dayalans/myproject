package space.gavinklfong.demo.streamapi;

public class Test {

	public static void main(String[] args) {
		 String s="TCSE.SC.300001";
		 System.out.println(Long.parseLong(s.substring(8)));

	}

}
