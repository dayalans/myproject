package space.gavinklfong.demo.streamapi;

import java.time.LocalDate;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import net.bytebuddy.asm.Advice.Exit;
import space.gavinklfong.demo.streamapi.models.Order;
import space.gavinklfong.demo.streamapi.models.Product;
import space.gavinklfong.demo.streamapi.repos.CustomerRepo;
import space.gavinklfong.demo.streamapi.repos.OrderRepo;
import space.gavinklfong.demo.streamapi.repos.ProductRepo;

@Slf4j
@Component
public class AppCommandRunner implements CommandLineRunner {

	@Autowired
	private CustomerRepo customerRepos;
	
	@Autowired
	private OrderRepo orderRepos;
	
	@Autowired
	private ProductRepo productRepos;

	@Transactional
	@Override
	public void run(String... args) throws Exception {
		log.info("Customers:");
		customerRepos.findAll()
				.forEach(c -> log.info(c.toString()));

		log.info("Orders:");
		orderRepos.findAll()
				.forEach(o -> log.info(o.toString()));

		log.info("Products:");
		productRepos.findAll()
				.forEach(p -> log.info(p.toString()));
		log.info("----------------------------------------------------------");	
		
		log.info("Exercise 1 — Obtain a list of products belongs to category “Books” with price > 100");
		productRepos.findAll().stream()
		.filter(p->p.getCategory().equals("Books"))
		.filter(p->p.getPrice()>100)
		.collect(Collectors.toList())
		.forEach(p -> log.info(p.toString()));
		
		log.info("Exercise 2 — Obtain a list of order with products belong to category “Baby”");
		List<Order> excercise2=orderRepos.findAll()
		.stream()
		.filter(o->o.getProducts().stream().anyMatch(p->p.getCategory().equalsIgnoreCase("Baby"))).collect(Collectors.toList());
		
		excercise2.stream().forEach(o->o.getProducts().stream().forEach(p->log.info(p.toString())));
		
		log.info("Exercise 3 — Obtain a list of product with category = “Toys” and then apply 10% discount");
		
		List<Product> list=productRepos.findAll().stream()
				.filter(p -> p.getCategory().equalsIgnoreCase("Baby"))
				 .map(p -> p.withPrice(p.getPrice() * 0.9))
				 .collect(Collectors.toList());
		
		list.stream().forEach(p->log.info(p.toString()));
		
		log.info("Exercise 4 — Obtain a list of products ordered by customer of tier 2 between 01-Feb-2021 and 01-Apr-2021");
		
		List<Product> excercise4=orderRepos.findAll().stream()
				.filter(o->o.getCustomer().getTier()==2)
				 .filter(o -> o.getOrderDate().compareTo(LocalDate.of(2021, 2, 1)) >= 0)
				  .filter(o -> o.getOrderDate().compareTo(LocalDate.of(2021, 4, 1)) <= 0)
				  .flatMap(o->o.getProducts().stream())
				  .distinct()
				  .collect(Collectors.toList());
			
		excercise4.stream().forEach(p->log.info(p.toString()));
		
		log.info("Exercise 5 —  Get the cheapest products of “Books” category");
		Product excercise5=productRepos.findAll().stream()
				.filter(p->p.getCategory().equalsIgnoreCase("Books"))
				.sorted(Comparator.comparing(Product::getPrice))
				.findFirst().get();
		System.out.println(excercise5.toString());
		Product excercise5New=productRepos.findAll().stream()
				.filter(p->p.getCategory().equalsIgnoreCase("Books"))
				.min(Comparator.comparing(Product::getPrice)).get();
		System.out.println(excercise5New.toString());
	
	
	
	
	
	log.info("Exercise 6 — Get the 3 most recent placed order");
	
	List<Order> excercise6=orderRepos.findAll().stream()
			.sorted(Comparator.comparing(Order::getOrderDate).reversed())
					.limit(3).collect(Collectors.toList());
	
	System.out.println(excercise6.toString());	
			
			
	log.info("Exercise 7 — Get a list of orders which were ordered on 15-Mar-2021, log the order records to the console and then return its product list");
	
	orderRepos.findAll().stream()
			.filter(o->o.getOrderDate().equals(LocalDate.of(2021, 3, 15)))
			.peek(o->System.out.println(o.toString()))
			.flatMap(o->o.getProducts().stream()).distinct().collect(Collectors.toList()).forEach(p->System.out.println(p.toString()));
			
	
	log.info("Exercise 8 — Calculate total lump sum of all orders placed in Feb 2021");	
	 Double result = orderRepos.findAll().stream()
	 .filter(o -> o.getOrderDate().compareTo(LocalDate.of(2021, 2, 1)) >= 0)
	  .filter(o -> o.getOrderDate().compareTo(LocalDate.of(2021, 3, 1)) < 0)
	  .flatMap(o->o.getProducts().stream())
			  .mapToDouble(p->p.getPrice()).sum();
	 
	 System.out.println("Exercise 8 — Calculate total lump sum of all orders placed in Feb 2021 "+result);
			
			
	 log.info("Exercise 9 — Calculate order average payment placed on 14-Mar-2021");
	 
	    Double averagepaymentresult = orderRepos.findAll()
	            .stream()
	            .filter(o -> o.getOrderDate().isEqual(LocalDate.of(2021, 3, 15)))
	            .flatMap(o -> o.getProducts().stream())
	            .mapToDouble(p -> p.getPrice())
	            .average().getAsDouble();
	 
	    
	    System.out.println("Exercise 9 — Calculate order average payment placed on 14-Mar-2021"+averagepaymentresult);
	    
	    log.info("Exercise 10 — Obtain a collection of statistic figures (i.e. sum, average, max, min, count) for all products of category “Books”");
	    DoubleSummaryStatistics statistics = productRepos.findAll()
	    	    .stream()
	    	    .filter(p -> p.getCategory().equalsIgnoreCase("Books"))
	    	    .mapToDouble(p -> p.getPrice())
	    	    .summaryStatistics();
	    	  
System.out.println(String.format("count = %1$d, average = %2$f, max = %3$f, min = %4$f, sum = %5$f", statistics.getCount(), statistics.getAverage(), statistics.getMax(), statistics.getMin(), statistics.getSum()));
	    	  
	 
			
			
			
			
			System.exit(1);
	}
	
}
